# MyJoghurtProjectCodes - Wang Zheng Division
A guide for possible HIWI that comes to my position in future.

## Getting start on this division Brief Overview

In main runs 3 part of huge POUs (HBFG_Logic,MHTS,ControlPanel) and 2 parts of conmmunication staffs yet I dont familier with. 
HBFG_Logic governs the overall visualiyation part of PLC for HMI or something that not belongs to control
MHTS contains transport system POUs and storage system (for now belongs to another HIWI)
ControlPanel is a realization part of the little control box with 4 button, which lies on the table.

And of course, my part is to implement the transportation part of the MHTS. this transportation part of POUs a muster class under FBs folder. and those classes are instanciated many times as you can see there are many CGs.
Each CGs corresponds to a region governed by different switches(you can see it in a clearer manner in 'factory map Zheng Wnag' you will thank me for this later on)

Notice, there have been alot of changes for device layout(for example a switch ,say S21, may be removed to other region and you will have to change all staff manually).

## Code Strukture

I designed a way to control bottle in oder to reach 2 diff-t destination,. in GVL list you can find a oder list for one bottle for a pre-defined path in plant.
in each CGs, the oder will be check if it is relavent and if so, the inhalt of oder will be read and implemented, and then the oder will be updated in the end of each CGs or will be manually updated in some speciall situation( see S23 for example) 

In this case, it is possible for each bottle to have diff-t destination but with pre-defined path that have been checked many times before( suppose no change of layout)

## thank you for reading good luck


